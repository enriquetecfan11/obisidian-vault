import os, json, subprocess, shutil, time, datetime
from pathlib import Path
VAULT=Path('/home/enriquetecfan/Documents/obisidian-vault')
SNAP=VAULT/'MaraOs/SystemFiles/ops/ubuntu-hourly-last.json'
now=datetime.datetime.now().astimezone()

def run(cmd, timeout=5):
    try:
        p=subprocess.run(cmd, shell=True, text=True, capture_output=True, timeout=timeout)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except subprocess.TimeoutExpired:
        return 124,'','timeout'
    except Exception as e:
        return 127,'',str(e)

def readf(p):
    try: return Path(p).read_text().strip()
    except: return None

up=readf('/proc/uptime')
uptime_s=float(up.split()[0]) if up else 0
uptime_txt=(f'{int(uptime_s//86400)}d ' if uptime_s>=86400 else '')+f'{int((uptime_s%86400)//3600)}h {int((uptime_s%3600)//60)}m'
load=os.getloadavg(); cores=os.cpu_count() or 1
ct1=readf('/proc/stat').splitlines()[0].split()[1:]
time.sleep(0.35)
ct2=readf('/proc/stat').splitlines()[0].split()[1:]
a=list(map(int,ct1)); b=list(map(int,ct2)); dif=[b[i]-a[i] for i in range(len(a))]
total=sum(dif); idle=dif[3]+(dif[4] if len(dif)>4 else 0)
cpu=round((1-idle/total)*100,1) if total else None
mem={}
for line in readf('/proc/meminfo').splitlines():
    k,v=line.split(':',1); mem[k]=int(v.strip().split()[0])
mt=mem['MemTotal']; ma=mem.get('MemAvailable',0); mu=mt-ma
mem_pct=round(mu/mt*100,1); mem_used_gb=round(mu/1024/1024,1); mem_avail_gb=round(ma/1024/1024,1); mem_total_gb=round(mt/1024/1024,1)
st=shutil.disk_usage('/'); root_pct=round(st.used/st.total*100,1); root_free=round(st.free/1024**3,1)
if VAULT.exists():
    vst=shutil.disk_usage(str(VAULT)); vault_info={'exists':True,'pct':round(vst.used/vst.total*100,1),'free_gb':round(vst.free/1024**3,1),'total_gb':round(vst.total/1024**3,1)}
else:
    vault_info={'exists':False}

fmt='{{.Names}}|{{.Image}}|{{.Status}}|{{.Ports}}'
rc,out,err=run(f"docker ps -a --format '{fmt}'",6)
if rc!=0:
    grc,gout,gerr=run('getent group docker',3)
    if grc==0 and 'enriquetecfan' in gout:
        rc,out,err=run(f"sg docker -c \"docker ps -a --format '{fmt}'\"",8)
containers=[]
if rc==0:
    for line in out.splitlines():
        parts=line.split('|',3)
        if len(parts)==4:
            containers.append({'name':parts[0],'image':parts[1],'status':parts[2],'ports':parts[3]})
active=[c for c in containers if c['status'].lower().startswith('up')]
problem=[c for c in containers if any(x in c['status'].lower() for x in ['exited','restarting','unhealthy','dead'])]
if rc==0 and containers:
    names=' '.join([c['name'] for c in containers])
    irc,iout,ierr=run("docker inspect --format '{{.Name}}|{{.RestartCount}}|{{if .State.Health}}{{.State.Health.Status}}{{end}}|{{.State.Status}}' "+names,8)
    if irc==0:
        inspect={}
        for l in iout.splitlines():
            p=l.split('|')
            if len(p)>=4:
                try: r=int(p[1])
                except: r=0
                inspect[p[0].lstrip('/')]={'restarts':r,'health':p[2], 'state':p[3]}
        for c in containers:
            c.update(inspect.get(c['name'],{}))

services=['openclaw','gateway','n8n','redis','postgres','nocodb','qdrant']
core=[]
psrc,psout,pserr=run("ps -eo comm,args --no-headers | egrep -i 'openclaw|gateway|n8n|redis|postgres|nocodb|qdrant' | grep -v egrep",5)
pslow=psout.lower()
for s in services:
    dc=[c for c in containers if s in (c['name']+' '+c['image']).lower()]
    if dc:
        states=[]
        for c in dc:
            states.append(c.get('state') or ('up' if c['status'].lower().startswith('up') else c['status'].split()[0]))
        core.append({'name':s,'state':','.join(sorted(set(states))),'source':'docker'})
    elif s in pslow or (s=='postgresql' and 'postgres' in pslow):
        core.append({'name':s,'state':'running','source':'proc'})
    else:
        rc2,out2,err2=run(f"systemctl is-active {s} 2>/dev/null",3)
        if rc2==0:
            core.append({'name':s,'state':out2,'source':'systemd'})

urc,uout,uerr=run("apt list --upgradable 2>/dev/null | tail -n +2 | wc -l",8)
updates=None if urc!=0 else int(uout.strip() or 0)
prc,pout,perr=run("ps -eo pid=,comm=,pcpu=,pmem= --sort=-pcpu | head -n 8",5)
anom=[]
if prc==0:
    for l in pout.splitlines():
        parts=l.rsplit(None,2)
        if len(parts)==3:
            left,pc,pm=parts; lp=left.split(None,1); pid=lp[0]; comm=lp[1] if len(lp)>1 else '?'
            try: pc=float(pc); pm=float(pm)
            except: continue
            if pc>=50 or pm>=15:
                anom.append({'pid':pid,'cmd':comm,'cpu':pc,'mem':pm})
prev=None
try: prev=json.loads(SNAP.read_text())
except Exception: pass

def delta(cur,key):
    if not prev or key not in prev: return None
    try: return round(cur-prev[key],1)
    except: return None
issues=[]; crit=[]
if root_pct>=95: crit.append(f'disco / {root_pct}%')
elif root_pct>=85: issues.append(f'disco / {root_pct}%')
if mem_pct>=92: crit.append(f'RAM {mem_pct}%')
elif mem_pct>=80: issues.append(f'RAM {mem_pct}%')
if load[0] >= cores*2: crit.append(f'load {load[0]:.2f}')
elif load[0] >= cores: issues.append(f'load {load[0]:.2f}')
if rc!=0: issues.append('Docker no comprobado')
if problem: issues.append(f'{len(problem)} contenedores con estado no OK')
for c in containers:
    if any(x in (c.get('state','')+' '+c['status']).lower() for x in ['restarting','unhealthy','dead']):
        crit.append(f"{c['name']} {c['status']}")
if updates and updates>=50: issues.append(f'{updates} updates pendientes')
status='CRÍTICO' if crit else ('WARNING' if issues else 'OK')
reason=(crit[0] if crit else (issues[0] if issues else 'métricas normales y sin anomalías relevantes'))
changes=[]
if prev:
    for label,key,cur,thr in [('CPU','cpu_pct',cpu,15),('RAM','mem_pct',mem_pct,8),('disco /','root_pct',root_pct,3),('load','load1',round(load[0],2),1.0)]:
        d=delta(cur,key)
        if d is not None and abs(d)>=thr:
            changes.append(f'{label} {d:+g}')
    prev_names=set(prev.get('containers',{}).keys()); cur_names=set(c['name'] for c in containers)
    new=cur_names-prev_names; gone=prev_names-cur_names
    if new: changes.append('nuevos contenedores: '+', '.join(sorted(new)[:3]))
    if gone: changes.append('desaparecen: '+', '.join(sorted(gone)[:3]))
    prev_restarts=prev.get('restarts',{}); inc=[]
    for c in containers:
        r=c.get('restarts',0)
        if r>prev_restarts.get(c['name'],0): inc.append(f"{c['name']} +{r-prev_restarts.get(c['name'],0)}")
    if inc: changes.append('reinicios: '+', '.join(inc[:3]))
else:
    changes.append('sin histórico comparable')
SNAP.parent.mkdir(parents=True, exist_ok=True)
snap={'ts':now.isoformat(),'cpu_pct':cpu,'mem_pct':mem_pct,'root_pct':root_pct,'vault_pct':vault_info.get('pct') if vault_info else None,'load1':round(load[0],2),'docker_ok':rc==0,'containers':{c['name']:{'status':c['status'],'image':c['image'],'ports':c['ports']} for c in containers},'restarts':{c['name']:c.get('restarts',0) for c in containers}}
SNAP.write_text(json.dumps(snap,ensure_ascii=False,indent=2))
hh=now.strftime('%H:%M')
lines=[f'Ubuntu Ops — {hh} — {status}', '', f'Estado: {status} — {reason}.']
lines.append(f'Sistema: uptime {uptime_txt}; CPU {cpu}%; RAM {mem_used_gb}/{mem_total_gb}GB ({mem_pct}%, libre {mem_avail_gb}GB); load {load[0]:.2f}/{load[1]:.2f}/{load[2]:.2f}.')
vi=f"vault {vault_info['pct']}% ({vault_info['free_gb']}GB libres)" if vault_info and vault_info.get('exists') else 'vault no encontrado'
lines.append(f'Disco: / {root_pct}% ({root_free}GB libres); {vi}.')
if rc==0:
    probtxt='; problemas: '+', '.join([p['name']+' '+p['status'] for p in problem[:3]]) if problem else '; sin unhealthy/restarting.'
    rel=[]
    for c in containers:
        if any(s in (c['name']+' '+c['image']).lower() for s in services):
            rel.append(f"{c['name']}:{c['status'].split(' (')[0]}")
    coretxt=', '.join(rel[:5]) if rel else (', '.join([f"{x['name']}:{x['state']}" for x in core]) or 'sin core relevante detectado')
    lines.append(f'Docker/Core: Docker OK ({len(active)} activos/{len(containers)} total){probtxt} Core: {coretxt}.')
else:
    lines.append(f'Docker/Core: Docker no comprobado ({err or "sin salida"}). Core detectado: '+(', '.join([f"{x['name']}:{x['state']}" for x in core]) or 'no relevante')+'.')
extra=[]
if updates is None: extra.append('updates no comprobadas')
elif updates: extra.append(f'updates {updates} pendientes')
if anom: extra.append('procesos altos: '+', '.join([f"{a['cmd']} CPU {a['cpu']}% RAM {a['mem']}%" for a in anom[:2]]))
if extra: lines.append('Señales: '+'; '.join(extra)+'.')
lines.append('Diferencial: '+('; '.join(changes[:4]) if changes else 'sin cambios relevantes')+'.')
if status=='OK':
    lines.append('Riesgos / acciones: Todo normal.')
else:
    acts=[]
    if crit: acts.append('P1 revisar '+crit[0])
    if problem: acts.append('P2 revisar contenedores problemáticos')
    if updates and updates>=50: acts.append('P3 planificar actualizaciones')
    if rc!=0: acts.append('P2 revisar permisos/daemon Docker')
    if not acts and issues: acts.append('P2 vigilar '+issues[0])
    lines.append('Riesgos / acciones: '+'; '.join(acts[:3])+'.')
print('\n'.join(lines))
