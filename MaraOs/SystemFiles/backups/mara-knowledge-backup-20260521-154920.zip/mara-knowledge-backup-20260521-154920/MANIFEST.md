# Mara Knowledge Backup

Created: 2026-05-21T15:49:20+02:00
Host: master-claw
User: enriquetecfan

Included:
- /home/enriquetecfan/.openclaw/workspace excluding .git, .trash, backups
- /home/enriquetecfan/Documents/obisidian-vault/MaraOs excluding vault .git/.obsidian
- /home/enriquetecfan/.openclaw/cron/jobs.json and jobs-state.json

Excluded intentionally: OpenClaw global config/secrets, tokens, node_modules, git internals, caches and large logs.
